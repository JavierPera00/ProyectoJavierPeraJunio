package com.ProyectoJunio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoJunioApplicationTests {

	@Test
	void contextLoads() {
	}

}
