package com.ProyectoJunio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ProyectoJunio.model.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
   
	Usuario findByUsernameIgnoreCase(String username);
	
	Usuario findByEmailIgnoreCase(String email);

}