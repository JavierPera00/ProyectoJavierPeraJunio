package com.ProyectoJunio.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.ProyectoJunio.model.Noticia;
import com.ProyectoJunio.servicio.NoticiaService;

@RestController
@RequestMapping("/api/noticias")
@CrossOrigin(origins = "*")
public class NoticiaController {
	
	    @Autowired
	    private NoticiaService noticiaService;

	    @GetMapping
	    public ResponseEntity<List<Noticia>> getAll() {
	        return ResponseEntity.ok(noticiaService.findAll());
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<Noticia> getById(@PathVariable Long id) {
	        Noticia noticia = noticiaService.findById(id);
	        if (noticia == null) {
	        	return ResponseEntity.notFound().build();
	        }
			return ResponseEntity.ok(noticia);
	    }

	    @PostMapping
	    public ResponseEntity<Noticia> create(@RequestBody Noticia noticia) {
	        return ResponseEntity.ok(noticiaService.save(noticia));
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<Noticia> update(@PathVariable Long id, @RequestBody Noticia noticia) {
	        Noticia existing = noticiaService.findById(id);
	        if (existing == null) {
	        	return ResponseEntity.notFound().build();
	        }
	        existing.setTitulo(noticia.getTitulo());
	        existing.setDescripcion(noticia.getDescripcion());
	        existing.setUrlImagen(noticia.getUrlImagen());
	        existing.setUrlExterna(noticia.getUrlExterna());
	        existing.setFechaPublicacion(noticia.getFechaPublicacion());
	        return ResponseEntity.ok(noticiaService.save(existing));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> delete(@PathVariable Long id) {
	        Noticia existing = noticiaService.findById(id);
	        if (existing == null) {
	            return ResponseEntity.notFound().build(); 
	        }
	        noticiaService.delete(id); 
	        return ResponseEntity.noContent().build(); 
	    }

	    @GetMapping("/ultimas")
	    public ResponseEntity<List<Noticia>> getUltimas() {
	        return ResponseEntity.ok(noticiaService.ultimasNoticias());
	    }   
}

