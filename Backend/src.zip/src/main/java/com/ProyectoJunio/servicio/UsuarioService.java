package com.ProyectoJunio.servicio;

import java.util.List;
import com.ProyectoJunio.model.Usuario;

public interface UsuarioService {

    public List<Usuario> findAll();

    public Usuario findById(Long id);

    public Usuario save(Usuario usuario);

    public void delete(Long id);
    
    public Usuario findByUsername(String name);
    
    public Usuario findByEmail(String email);

}