package com.ProyectoJunio.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ProyectoJunio.model.Curso;
import com.ProyectoJunio.repository.CursoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CursoServiceImp implements CursoService {

	@Autowired
	private CursoRepository cursoRepository;

	public List<Curso> findAll() {
		return cursoRepository.findAll();
	}

	public Curso findById(Long id) {
		return cursoRepository.findById(id).orElse(null);
	}

	public Curso save(Curso curso) {
		return cursoRepository.save(curso);
	}

	public void delete(Long id) {
		cursoRepository.deleteById(id);
	}

	@Override
	public List<Curso> findByTitulo(String titulo) {
		return cursoRepository.findByTituloContainingIgnoreCase(titulo);
	}
}