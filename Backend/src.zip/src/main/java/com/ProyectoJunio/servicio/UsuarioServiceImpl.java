package com.ProyectoJunio.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ProyectoJunio.model.Usuario;
import com.ProyectoJunio.repository.UsuarioRepository;

@Service
public class UsuarioServiceImpl implements UsuarioService {

	@Autowired
	private UsuarioRepository usuarioRepository;

	public List<Usuario> findAll() {
		return usuarioRepository.findAll();
	}

	public Usuario findById(Long id) {
		return usuarioRepository.findById(id).orElse(null);
	}

	public Usuario save(Usuario usuario) {
		return usuarioRepository.save(usuario);
	}

	public void delete(Long id) {
		usuarioRepository.deleteById(id);
	}

	public Usuario findByUsername(String name) {
		return usuarioRepository.findByUsernameIgnoreCase(name);
	}

	public Usuario findByEmail(String email) {
		return usuarioRepository.findByEmailIgnoreCase(email);
	}

}
