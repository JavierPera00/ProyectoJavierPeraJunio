package com.ProyectoJunio.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ProyectoJunio.model.Rol;
import com.ProyectoJunio.repository.RolRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class RolServiceImpl implements RolService {

	@Autowired
	private RolRepository rolRepository;

	public List<Rol> findAll() {
		return rolRepository.findAll();
	}

	public Rol findById(Long id) {
		return rolRepository.findById(id).orElse(null);
	}

	public Rol save(Rol rol) {
		return rolRepository.save(rol);
	}

	public void delete(Long id) {
		rolRepository.deleteById(id);
	}
}
