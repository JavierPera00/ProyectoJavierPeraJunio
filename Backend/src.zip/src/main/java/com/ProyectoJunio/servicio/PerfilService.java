package com.ProyectoJunio.servicio;

import java.util.List;
import com.ProyectoJunio.model.Perfil;

public interface PerfilService {

    public List<Perfil> findAll();

    public Perfil findById(Long id);

    public Perfil save(Perfil perfil);

    public void delete(Long id);
}
